# Kubernetes Security Scan

## Tools Used
- Minikube
- Kubescape

## How to Reproduce

1. Install Minikube and start the cluster:
   ```bash
   minikube start
